##                              Operating System Assignment

###### Task1:

 How to install ubuntu:

- First of all we download the VMware Software

  !![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 230626.png)

- After installing the VMware we install it and Open it and Create a Virtual Machine and  After installing the VMware we give the path of the ubuntu iOS file and after some processing our screen looks like in this way set Virtual Machine Location 

  !![](C:\Users\user\Pictures\Screenshots\2.png)

- Specify Virtual Machine Size

  !![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 230844.png)

- ​               Specify RAM and follow these Steps:

​              !  ![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 230911.png)

  !![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 231015.png)

![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 231030.png)

![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 231056.png)

![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 231119.png)

![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 231141.png)

- Ubuntu is Successfully Installed Further:

![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 231421.png)

![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 231220.png)

###### Task2:

- Install g++ and gcc Compiler using Terminal:
- Open Terminal and type These Commands

   ![](C:\Users\user\Pictures\Screenshots\Screenshot 2024-01-28 234750.png)

###### Tasks3:

1. GitHub Link:   https://github.com/awais1019/OS-Lab2.git

 